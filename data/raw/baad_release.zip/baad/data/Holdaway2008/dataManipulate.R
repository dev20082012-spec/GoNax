manipulate <- function(raw) {

  raw
}
