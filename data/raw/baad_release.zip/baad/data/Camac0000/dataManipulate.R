manipulate <- function(raw) {
  
  
  raw
}

