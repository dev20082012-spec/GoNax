manipulate <- function(raw){
  
  
  
  raw
}