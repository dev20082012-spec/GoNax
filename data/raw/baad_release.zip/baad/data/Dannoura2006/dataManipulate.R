manipulate  <-  function(raw){

	raw
}
