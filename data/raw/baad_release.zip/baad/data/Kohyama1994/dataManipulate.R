manipulate <- function(raw) {
 

  raw
}

