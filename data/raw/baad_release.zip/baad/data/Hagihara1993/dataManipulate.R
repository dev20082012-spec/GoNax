manipulate <- function(raw){
  
  
  raw
}