manipulate <- function(raw) {
    
  raw
}

