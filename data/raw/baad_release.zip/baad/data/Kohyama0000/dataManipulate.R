manipulate <- function(raw) {
   
  raw
}

