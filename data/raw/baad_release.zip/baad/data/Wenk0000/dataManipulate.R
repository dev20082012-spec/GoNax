manipulate <- function(raw) {
  raw
}

