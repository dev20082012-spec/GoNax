manipulate <- function(raw) {
  
  raw
}

